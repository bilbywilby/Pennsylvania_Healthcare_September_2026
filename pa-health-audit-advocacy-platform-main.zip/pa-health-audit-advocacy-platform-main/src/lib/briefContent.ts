/**
 * 2026 Forensic Market Intelligence Briefing
 * Decoupled content for the PA Health Audit Command Center
 */
export const TLDR_STATS = {
  statewideIncrease: "+21.5%",
  marketLeader: "Independence BC (Area 8)",
  volatilityPeak: "Ambetter (37.8%)",
  efficiencyLeader: "Jefferson (10.1% Shift)",
  fplCliffImpact: "102% Jump",
};
export const FORENSIC_MARKET_BRIEF = `
# 2026 Forensic Market Intelligence Briefing
## Statewide Impact Analysis
Forensic modeling of the Pennsylvania insurance marketplace for the 2026 plan year indicates a **+21.5% weighted average premium increase**. This volatility is driven by the expiration of ARPA subsidy expansions and high-cost specialty drug spend.
## Carrier Outliers
Significant regional price divergence has been detected among major carriers:
*   **Ambetter (Centene):** +37.8% spike in Silver tier benchmarks (Areas 2, 6, 8).
*   **Jefferson Health Plans:** 10.1% strategic efficiency shift in HMO networks.
*   **Highmark/UPMC:** Narrowing provider alignment leading to a 12% baseline increase in Western PA.
## Regional Intelligence Highlights
*   **Rating Area 1 (Pittsburgh):** Shift toward HSA-compatible Silver plans for maximum tax efficiency.
*   **Rating Area 3 (Central):** Rare downward price pressure due to Capital Blue Cross expansion.
*   **Rating Area 6 (Lehigh Valley):** Highest churn risk; St. Luke's vs. LVHN alignment is critical.
*   **Rating Area 8 (Philadelphia):** Extreme 'Unbundling' risks; forensic EOB audit mandatory for all inpatient stays.
## Institutional Strategic Protocols
1.  **HSA Forensic Audit:** Mandatory verification of deductible-to-subsidy ratios for 250% FPL households.
2.  **400% FPL Monitoring:** Real-time income tracking to prevent the "102% Net Premium Jump" at the ARPA cliff.
3.  **Act 68 Readiness:** Pre-authorization of external grievance documentation for all specialty referrals.
`;