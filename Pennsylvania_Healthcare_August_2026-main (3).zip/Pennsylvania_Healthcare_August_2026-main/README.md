# Pennsylvania Healthcare — August 2026 Status Report

A publicly-sourced summary of Pennsylvania's state-based ACA marketplace (Pennie)
following the December 2025 expiration of federal Enhanced Premium Tax Credits.
Covers enrollment decline (497K → 431K), approved 2026 carrier rate filings,
county-level disenrollment data, the unfunded Act 54 state subsidy program, and
confirmed 2027 Open Enrollment changes.

Every claim is drawn from a primary source — PHIEA/Pennie, the PA Insurance
Department, PHAN, or named news outlets — and hyperlinked inline in APA format.
No projections, quotes, or figures appear without a verifiable source; where
something couldn't be confirmed, that is stated explicitly rather than filled in.

## Contents

| File | Description |
|---|---|
| `Pennsylvania_Health_Insurance_August_2026_Status_Report.pdf` | Final report, formatted with hyperlinked inline APA citations |
| `PA_Health_Insurance_Audit_August_2026.md` | Markdown source for the report |

## Key Findings

- Pennie enrollment fell from a 2025 peak of ~497,000 to 431,270 by July 1, 2026 — a loss of 177,000+ covered lives.
- Average net premiums for enrollees who kept coverage rose 102%, against a 21.5% approved statewide gross rate increase.
- 15 of the 20 highest-disenrollment counties are rural; Schuylkill County led at 24%, after two of its three ACA carriers withdrew.
- Pennsylvania's state premium-assistance program (Act 54 of 2024) remains unfunded as of the most recent confirmed reporting.
- Pennie has confirmed Open Enrollment 2027 will run October 15 – December 15, 2026.

## Sourcing Standard

This report was built specifically to avoid a failure mode common in AI-assisted
research: plausible-sounding but unverified statistics, invented expert quotes,
and citations that don't actually support the claims attached to them. To guard
against that:

- Every statistic is linked to the specific government, marketplace, or news page it came from.
- Claims that could not be independently verified against a live source were explicitly excluded rather than included with a citation of convenience.
- A "Methodological Rigor and Verified Exclusions" section in the report documents what was cut, and why.

## License

Released under the [MIT License](LICENSE). The underlying data belongs to its
original publishers (PHIEA/Pennie, the Pennsylvania Insurance Department, PHAN,
and the news outlets cited); this repository only compiles and cites it.

## Disclaimer

This is an independent compilation, not an official publication of the
Commonwealth of Pennsylvania, PHIEA, Pennie, or PID. Figures reflect the most
recent data confirmed at time of writing (August 2026) — check the linked
sources directly for anything more current.
