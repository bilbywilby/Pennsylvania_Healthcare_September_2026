# Pennsylvania Health Insurance: August 2026 Status Report

*An independent, publicly-sourced summary of Pennsylvania's ACA marketplace (Pennie) as of August 2026. Every figure is drawn from a government agency, the state marketplace, or a named news/policy source, each cited below. Where the underlying facts could not be confirmed, that is stated explicitly rather than filled in.*

---

## Executive Summary

Following the expiration of federal Enhanced Premium Tax Credits (EPTCs) on December 31, 2025, Pennsylvania's state-based marketplace, Pennie, has experienced its steepest enrollment decline on record. Enrollment fell from a 2025 peak of roughly 497,000 to 431,270 by July 1, 2026 — a loss of more than 177,000 people since the start of Open Enrollment 2026 (PHIEA, 2026a). Enrollees who kept coverage saw premiums rise by an average of 102%, more than the 21.5% gross rate increase approved by the state regulator alone would suggest, reflecting the additional loss of federal subsidy dollars (PHIEA, 2026a; PID, 2026a).

The impact has been concentrated in rural counties: 15 of the 20 counties with the highest disenrollment rates are rural, led by Schuylkill County at 24%, where two of three ACA carriers withdrew entirely (PHIEA, 2026d; PID, 2026a). Pennsylvania has an enacted-but-unfunded state subsidy program (Act 54 of 2024) that, if funded, would work similarly to programs already operating in New Jersey, Colorado, Washington, and California — but as of the most recent reporting located (May 2026), it remains unfunded (ForHealthInsurance.com, 2026).

Separately, a federal rule (the 2025 Marketplace Integrity and Affordability Final Rule) will shorten open enrollment windows nationwide starting with plan year 2027 and change certain re-enrollment mechanics — details below.

---

## Key Statistics

| Metric | Figure | Source |
|---|---|---|
| Enrollment, 2025 peak | ~497,000 | PHIEA, 2026a |
| Enrollment, July 1, 2026 | 431,270 | PHIEA, 2026a |
| Cumulative cancellations since OE 2026 start | 177,000+ | PHIEA, 2026a |
| Average net premium increase (enrollees who kept coverage) | 102% | PHIEA, 2026a |
| Statewide approved gross rate increase | 21.5% | PID, 2026a |
| Federal EPTC subsidy value lost annually (PA) | ~$600 million | PHIEA, 2026a |
| State replacement funding appropriated | $0 (as of May 2026) | ForHealthInsurance.com, 2026 |
| Highest county disenrollment rate | 24% (Schuylkill) | PHIEA, 2026d |
| Rural counties among 20 highest-disenrollment counties | 15 of 20 (75%) | PHIEA, 2026d |

---

## Enrollment Timeline

| Date | Enrollment | Note |
|---|---|---|
| 2025 (peak) | ~497,000 | Record high under EPTC |
| Feb 1, 2026 | 486,000 | End of Open Enrollment 2026 (85,000 terminated during OE) |
| Jun 1, 2026 | 443,024 | 160,000+ cumulative cancellations |
| Jul 1, 2026 | 431,270 | 177,000+ cumulative cancellations (94,000 dropped post-OE) |

*(PHIEA, 2026a, b)*

---

## Premium Rate Filings (Individual Market)

The Pennsylvania Insurance Department approved a statewide weighted-average gross increase of 21.5%, while denying $50.1 million in requested increases it judged unjustified. PID attributed the increases to the EPTC expiration combined with rising prescription drug costs and utilization (PID, 2026a).

| Carrier | Requested | Approved |
|---|---|---|
| Ambetter Health of Pennsylvania | 30.1% | 37.8% |
| UPMC Health Plan | 16.3% | 24.8% |
| UPMC Health Options | 11.7% | 20.2% |
| Keystone Health Plan East | 23.5% | 22.0% |
| Capital Advantage Assurance | 26.0% | 24.6% |
| Oscar Health Plan of PA | 21.6% | 23.1% |
| Highmark Benefits Group | — | 21.0% |
| Jefferson Health Plans PPO (Partners Insurance) | — | 20.5% |
| QCC Insurance Company | 16.7% | 15.2% |
| Geisinger Quality Options | 16.2% | 13.8% |
| Geisinger Health Plan | 14.1% | 11.6% |
| Partners Insurance Company | -10.1% | -10.1% (sole decrease) |

*(PID, 2026a)*

At the close of Open Enrollment, Pennsylvania Insurance Commissioner Michael Humphreys said: "The Pennsylvania Insurance Department encourages all consumers in need of quality health insurance coverage to act fast and sign up for affordable coverage through Pennie before the end of Open Enrollment" (as quoted in ACA Signups, 2026).

---

## County-Level Attrition

Pennie's official county termination data (through February 1, 2026) shows Schuylkill County with the state's highest termination rate. Of the top 20 highest-attrition counties, 15 (75%) are rural (PHIEA, 2026d).

| County | Termination % | Designation |
|---|---|---|
| Schuylkill | 24% | Rural |
| Lehigh | 22% | Urban |
| Northampton | 22% | Urban |
| Lancaster | 22% | Urban |
| Greene | 22% | Rural |
| Fulton | 22% | Rural |
| Tioga | 21% | Rural |
| Monroe | 21% | Rural |
| Franklin | 21% | Rural |
| Juniata | 20% | Rural |
| Mifflin | 20% | Rural |
| Beaver | 20% | Urban |
| Snyder | 20% | Rural |
| Adams | 19% | Rural |
| Lebanon | 19% | Rural |
| Carbon | 19% | Rural |
| Blair | 19% | Rural |
| York | 19% | Rural |
| Cumberland | 19% | Urban |
| Clearfield | 19% | Rural |

*(PHIEA, 2026d)*

Schuylkill's attrition coincided with the withdrawal of two of its three ACA carriers — Ambetter Health and Partners Insurance Company both left the county's 2026 coverage map, leaving UPMC as the sole remaining carrier. Residents faced an average monthly premium increase of 186%, about $347 more per person per month (Pottsville Republican Herald, 2026).

*Note: A county-by-county congressional district map, similar to what appeared in earlier draft materials, is not included here — no verified, district-level attribution of these termination rates was found.*

---

## Consumer-Reported Affordability

A survey of 424 Pennsylvanians conducted by the Pennsylvania Health Access Network (PHAN) and the Pennsylvania Association of Community Health Centers, published April 29, 2026, found:

| Perception | 2025 | 2026 |
|---|---|---|
| Unaffordable | 38% | 62% |
| Affordable | 38% | 26% |
| Very affordable | 24% | 12% |

Roughly half of respondents said their plan doubled or tripled in cost for 2026; more than 1 in 6 said they planned to drop coverage; nearly 1 in 4 said they would downgrade to a cheaper plan with less coverage (PHAN, 2026).

*Note: Individual respondent quotes that circulated in earlier drafts of this material are not reproduced here, because they could not be independently re-confirmed against a live source in this session.*

---

## The State Health Insurance Affordability Program — Status and Peer-State Comparison

Act 54 of 2024 (Pennsylvania's fiscal code for Budget Year 2024–25) established the State Health Insurance Exchange Affordability Program, which would provide state-funded premium assistance stacked on top of federal subsidies (PHIEA, 2026c; HealthInsurance.org, 2026a). As of the most recent confirmed reporting (May 2026), the program has never received a funding appropriation, and Pennie and PID continue to advocate for it (ForHealthInsurance.com, 2026).

Several other states run comparable, funded programs. Verified 2026 figures:

| State | Program Structure |
|---|---|
| New Jersey | NJ Health Plan Savings; premium subsidy for incomes up to 600% FPL (Health­Insurance.org, 2026b) |
| Colorado | Up to $80/month for the first household member, $29/month per additional member, for APTC-eligible consumers, extending premium assistance to 400% FPL (SHVS, 2026) |
| Washington | Cascade Care Savings; flat $55 per member per month, up to $250/month for those ineligible for federal subsidies (SHVS, 2026) |
| California | $190 million allocated for 2026, targeted at incomes up to 150% FPL (HealthInsurance.org, 2026c) |
| Pennsylvania | Enacted (Act 54, 2024) but **unfunded** as of May 2026 (ForHealthInsurance.com, 2026) |

*Note: Earlier drafts of this material cited a "$2.7 billion" California figure and specific ROI ratios (e.g., "3:1 to 4.6:1") for a proposed Pennsylvania appropriation. Neither could be confirmed against a real source and both are omitted here. The $190 million California figure above is the one actually found in current reporting.*

---

## 2027 Open Enrollment: What's Actually Changing

A federal rule — the 2025 Marketplace Integrity and Affordability Final Rule (effective August 25, 2025) — makes several changes to ACA marketplaces nationwide, phased in through plan year 2027 (CMS, 2026; HealthInsurance.org, 2026d):

- **Shortened enrollment window:** Starting with plan year 2027, all individual-market exchanges — including state-based marketplaces like Pennie — must begin Open Enrollment no later than November 1 and end it no later than December 31, with the window capped at 9 weeks. The federally-facilitated marketplace (HealthCare.gov) specifically will run November 1–December 15 (CMS, 2026; SHVS, 2026b).
- **A specific auto-renewal protocol is removed:** The rule eliminates an auto-renewal mechanism HealthCare.gov adopted in 2024 that could switch some consumers into a different Bronze-tier plan automatically. This is narrower than a full elimination of auto-renewal (HealthInsurance.org, 2026d).
- **Low-income special enrollment period paused:** A year-round special enrollment period for people at or below 150% FPL is paused through plan year 2026, with CMS stating it will again be available at each exchange's option for 2027 (HealthInsurance.org, 2026d).

**What is not yet confirmed:** Pennie's specific Open Enrollment 2027 dates, and whether/how these federal changes will alter auto-renewal specifically for Pennie enrollees, were not found in a Pennie-published source as of this writing. Earlier drafts of this material asserted a specific Pennie 2027 window (Oct 15–Dec 15) and a claim that "all 431,000 enrollees" would lose coverage without active re-enrollment; neither of those specifics could be verified and they are not repeated here. Anyone relying on this for enrollment planning should check pennie.com directly closer to the 2027 Open Enrollment period.

---

## No Surprises Act — Consumer Protections

The Pennsylvania Insurance Department administers state-level enforcement of the federal No Surprises Act. Key protections (PID, 2026b):

- **Emergency services** must be covered without prior insurance approval, regardless of network status (ground ambulance is excluded).
- **Non-emergency services at an in-network facility** — if an individual provider there (e.g., a lab or pathologist) is out-of-network, services must still be billed at in-network rates.
- Consumers can submit a **No Surprises Bill Review Request** through PID's online portal, or call the Consumer Services Bureau at 1-877-881-6388 (TTY/TDD: 717-783-3898) (PID, 2026c).

---

## Consumer Resources

| Need | Contact |
|---|---|
| Enrollment assistance | Pennie: 1-844-844-8040 \| pennie.com |
| Insurance complaints | PID Consumer Services: 1-877-881-6388 \| pa.gov/agencies/insurance |
| Surprise bill review | PID No Surprises portal: pa.gov/services/insurance/request-a-review-of-an-unexpected-medical-bill-no-surprises-act |
| In-person enrollment help | Pennie-certified Assisters: pennie.com/connect |

---

## What This Report Deliberately Omits

To keep this document honest, the following elements that appeared in earlier draft materials are **not** included, because no verified source could be found for them:

- Named "expert" analysts, bios, or attributed quotes beyond the one sourced Commissioner Humphreys quote above
- A specific $50 million appropriation "ask," ROI ratios, or a projected count of enrollees a hypothetical appropriation would restore
- Uncompensated-care cost-shift estimates ($159M–$230M)
- A congressional-district-by-district termination map
- A specific claim that Pennie's 2027 auto-renewal policy will require all current enrollees to re-enroll or lose coverage
- Consumer testimonial quotes not independently re-confirmed in this session

---

## Sources

ACA Signups. (2026, January 23). *Pennsylvania: Pennie's final enrollment deadline is 1/31; avg net premiums have more than doubled, over 70K have dropped coverage already*. https://acasignups.net/26/01/23/pennsylvania-pennie%E2%80%99s-final-enrollment-deadline-131-avg-net-premiums-have-more-doubled-over

Centers for Medicare & Medicaid Services. (2026). *CMS finalizes major rule to lower individual health insurance premiums for Americans* [Press release]. https://www.cms.gov/newsroom/press-releases/cms-finalizes-major-rule-lower-individual-health-insurance-premiums-americans

ForHealthInsurance.com. (2026). *Affordable health insurance PA 2026: Cost & subsidy guide*. https://www.forhealthinsurance.com/pennsylvania-affordable-health-insurance/

HealthInsurance.org. (2026a). *Pennsylvania health insurance marketplace: 2026 ACA coverage guide*. https://www.healthinsurance.org/aca-marketplace/pennsylvania/

HealthInsurance.org. (2026b). *New Jersey health insurance marketplace: 2026 ACA coverage guide*. https://www.healthinsurance.org/aca-marketplace/new-jersey/

HealthInsurance.org. (2026c). *Which states offer their own health insurance subsidies?* https://www.healthinsurance.org/faqs/which-states-offer-their-own-health-insurance-subsidies/

HealthInsurance.org. (2026d). *New federal rule brings immediate changes to Marketplace enrollment*. https://www.healthinsurance.org/blog/new-federal-rule-brings-immediate-changes-to-marketplace-enrollment/

Pennsylvania Health Insurance Exchange Authority. (2026a). *Affordability*. Pennie. https://pennie.com/affordability/

Pennsylvania Health Insurance Exchange Authority. (2026b, February 9). *One in five Pennie enrollees drop health coverage due to expired federal tax credits* [Press release]. https://agency.pennie.com/one-in-five-pennie-enrollees-drop-health-coverage-due-to-expired-federal-tax-credits

Pennsylvania Health Insurance Exchange Authority. (2026c, April 26). *Pennsylvania agencies release insurance affordability survey results*. Pennsylvania Office of Rural Health. https://www.porh.psu.edu/pennsylvania-agencies-release-insurance-affordability-survey-results/

Pennsylvania Health Insurance Exchange Authority. (2026d, February 1). *Terminations by county during Open Enrollment 2026* [Data file]. Pennie. https://pennie.com/wp-content/uploads/2026/02/Open-Enrollment-Comparison-2021-2026-43-Terminations-by-County-OE-2026-2.pdf

Pennsylvania Health Access Network. (2026, April 29). *2026 survey shows Pennie plans are now unaffordable for most*. https://www.pahealthaccess.org/resource/2026-survey-shows-pennie-plans-are-now-unaffordable-for-most

Pennsylvania Insurance Department. (2026a). *Pennsylvania Insurance Department releases Affordable Care Act 2026 health insurance rates*. Commonwealth of Pennsylvania. https://www.pa.gov/agencies/insurance/newsroom/aca-2026-health-insurance-rates

Pennsylvania Insurance Department. (2026b). *No Surprises Act*. Commonwealth of Pennsylvania. https://www.pa.gov/agencies/insurance/laws-regulations-notices/no-surprises-act

Pennsylvania Insurance Department. (2026c). *Request a review of an unexpected medical bill — No Surprises Act*. Commonwealth of Pennsylvania. https://www.pa.gov/services/insurance/request-a-review-of-an-unexpected-medical-bill-no-surprises-act

Pottsville Republican Herald. (2026, January 15). *Expired healthcare subsidies prove 'devastating' for some in Schuylkill County*. https://www.republicanherald.com/2026/01/15/expired-healthcare-subsidies-prove-devastating-for-some-in-schuylkill-county

State Health & Value Strategies (SHVS). (2026). *State marketplace subsidies to support health insurance affordability*. https://shvs.org/wp-content/uploads/2026/03/SHVS_State-Marketplace-Subsidies-to-Support-Health-Insurance-Affordability_Final.pdf

State Health & Value Strategies (SHVS). (2026b). *Final federal marketplace integrity rule*. https://shvs.org/wp-content/uploads/2025/06/SHVS_2025-Final-Marketplace-Integrity-Rule.pdf
