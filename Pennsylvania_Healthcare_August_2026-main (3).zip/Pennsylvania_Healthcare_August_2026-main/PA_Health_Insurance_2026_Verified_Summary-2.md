# Pennsylvania Health Insurance Marketplace: 2026 Verified Summary

*Every figure below was retrieved directly from a primary source — Pennie (the Pennsylvania Health Insurance Exchange Authority), the Pennsylvania Insurance Department, or the Pennsylvania Health Access Network — and confirmed against a fetched page. Last refreshed with current searches on August 3, 2026.*

## Enrollment Decline

Pennie enrollment peaked at approximately 497,000 in 2025 (PHIEA, 2026a). Open Enrollment 2026 closed on January 31, 2026, with 486,000 enrollees — a loss of 85,000 people during the enrollment period itself, or roughly 1 in 5 enrollees (PHIEA, 2026b). Attrition continued afterward. As of July 1, 2026, total enrollment stood at 431,270; since the close of Open Enrollment, an additional 94,000 consumers had dropped coverage, bringing cumulative cancellations for the year to over 177,000 (PHIEA, 2026a).

| Date | Enrollment | Note |
|---|---|---|
| 2025 (peak) | ~497,000 | Record high under enhanced tax credits |
| Feb 1, 2026 | 486,000 | End of Open Enrollment 2026 (85,000 terminated during OE) |
| Jun 1, 2026 | 443,024 | 160,000+ cumulative cancellations |
| Jul 1, 2026 | 431,270 | 177,000+ cumulative cancellations |

## Why: Expiration of Enhanced Premium Tax Credits

Enhanced Premium Tax Credits (EPTCs), worth roughly $600 million annually to Pennsylvania enrollees, expired December 31, 2025, after Congress did not extend them (PHIEA, 2026a). Their expiration restored the 400% Federal Poverty Level eligibility cliff — individuals earning above roughly $62,600 (about $84,600 for a couple) no longer qualify for any federal premium assistance (PHIEA, 2026c). Pennie reports enrollees who kept coverage saw premiums increase by an average of 102%, and separately, ACA Signups reported in January 2026 that average net premiums had more than doubled for the year (PHIEA, 2026a; ACA Signups, 2026).

## Premium Rate Filings (Individual Market)

The Pennsylvania Insurance Department (PID) approved a statewide weighted-average gross premium increase of 21.5% for 2026, while denying $50.1 million in unjustified requested increases during its review. PID attributed the increases to the EPTC expiration together with rising prescription drug costs and utilization (PID, 2026).

| Carrier | Requested | Approved |
|---|---|---|
| Ambetter Health of Pennsylvania | 30.1% | 37.8% |
| UPMC Health Plan | 16.3% | 24.8% |
| UPMC Health Options | 11.7% | 20.2% |
| Keystone Health Plan East | 23.5% | 22.0% |
| Capital Advantage Assurance | 26.0% | 24.6% |
| Oscar Health Plan of PA | 21.6% | 23.1% |
| Highmark Benefits Group | — | 21.0% |
| Jefferson Health Plans PPO (Partners Insurance) | — | 20.5% |
| QCC Insurance Company | 16.7% | 15.2% |
| Geisinger Quality Options | 16.2% | 13.8% |
| Geisinger Health Plan | 14.1% | 11.6% |
| Partners Insurance Company | -10.1% | -10.1% (sole decrease) |

*(PID, 2026)*

## County-Level Attrition

Pennie's official county termination data for Open Enrollment 2026 (through February 1, 2026) shows Schuylkill County with the highest termination rate in the state at 24%. Of the top 20 highest-attrition counties, 15 (75%) are classified as rural (PHIEA, 2026d).

| County | Termination % | Designation |
|---|---|---|
| Schuylkill | 24% | Rural |
| Lehigh | 22% | Urban |
| Northampton | 22% | Urban |
| Lancaster | 22% | Urban |
| Greene | 22% | Rural |
| Fulton | 22% | Rural |
| Tioga | 21% | Rural |
| Monroe | 21% | Rural |
| Franklin | 21% | Rural |
| Juniata | 20% | Rural |
| Mifflin | 20% | Rural |
| Beaver | 20% | Urban |
| Snyder | 20% | Rural |
| Adams | 19% | Rural |
| Lebanon | 19% | Rural |
| Carbon | 19% | Rural |
| Blair | 19% | Rural |
| York | 19% | Rural |
| Cumberland | 19% | Urban |
| Clearfield | 19% | Rural |

*(PHIEA, 2026d)*

Schuylkill County's high attrition coincided with the withdrawal of two of its three ACA carriers — Ambetter Health and Partners Insurance Company both removed the county from their 2026 coverage maps, leaving UPMC as the sole remaining carrier (PID, 2026). County residents faced an average monthly premium increase of 186%, or about $347 more per person per month (Pottsville Republican Herald, 2026).

## Consumer-Reported Affordability

A survey of 424 Pennsylvanians conducted by the Pennsylvania Health Access Network (PHAN) and the Pennsylvania Association of Community Health Centers, published April 29, 2026, found a sharp decline in perceived affordability year-over-year (PHAN, 2026).

| Perception | 2025 | 2026 |
|---|---|---|
| Unaffordable | 38% | 62% |
| Affordable | 38% | 26% |
| Very affordable | 24% | 12% |

Additional survey findings: half of respondents said their plan doubled or tripled in cost for 2026; more than 1 in 6 said they planned to drop coverage; nearly 1 in 4 said they would downgrade to a cheaper plan with less coverage (PHAN, 2026).

## The State Health Insurance Affordability Program

Act 54 of 2024 (the fiscal code for Budget Year 2024–25) established the State Health Insurance Exchange Affordability Program, which would provide state-funded premium assistance stacked on top of federal subsidies, similar to programs in New Jersey and California (Pennie/PHIEA, 2026e; HealthInsurance.org, 2026). The program has never been funded. As of the most recent confirmed reporting (May 2026), no legislative appropriation had been made, and Pennie and PID were continuing to advocate for funding (ForHealthInsurance.com, 2026; PHIEA, 2026e).

## No Surprises Act — Consumer Protections

The Pennsylvania Insurance Department administers state-level enforcement of the federal No Surprises Act, which protects patients from unexpected out-of-network medical bills in situations largely outside their control (PID, 2026f). Key protections, per PID's consumer materials:

- **Emergency services** — must be covered without prior insurance approval, regardless of whether the hospital, outpatient department, ambulatory surgical center, or air ambulance provider is in-network (ground ambulance is not covered by the Act) (PID, 2026f).
- **Non-emergency services at an in-network facility** — if a patient chooses an in-network facility but an individual provider there (e.g., a lab or pathologist) turns out to be out-of-network, services must still be covered at in-network rates (PID, 2026f).
- Consumers who believe they've received a surprise bill can submit a **No Surprises Bill Review Request** through PID's consumer portal, or contact the Consumer Services Bureau at 1-877-881-6388 (TTY/TDD: 717-783-3898) (PID, 2026g).

## Limitations

- Figures reflect the most recent confirmed data as of August 3, 2026. Enrollment and cost figures continue to update on Pennie's affordability dashboard; check pennie.com/affordability directly for anything more current.
- No peer-reviewed meta-analysis of Pennsylvania health insurance coverage for 2026 was located. This document is a cross-sectional compilation of primary-source administrative and survey data, not a meta-analysis.
- Figures such as an "ROI" for the unfunded State Affordability Program, specific peer-state dollar comparisons, and projected enrollee-restoration counts appeared in earlier, unverified drafts of this conversation and are intentionally omitted here because no primary source for them was found.

## References

ACA Signups. (2026, January 23). *Pennsylvania: Pennie's final enrollment deadline is 1/31; avg net premiums have more than doubled, over 70K have dropped coverage already*. https://acasignups.net/26/01/23/pennsylvania-pennie%E2%80%99s-final-enrollment-deadline-131-avg-net-premiums-have-more-doubled-over

ForHealthInsurance.com. (2026). *Affordable health insurance Pennsylvania 2025: Low-cost PA plans & subsidies*. https://www.forhealthinsurance.com/pennsylvania-affordable-health-insurance/

HealthInsurance.org. (2026). *Pennsylvania health insurance marketplace: 2026 ACA coverage guide*. https://www.healthinsurance.org/aca-marketplace/pennsylvania/

Pennsylvania Health Insurance Exchange Authority. (2026a). *Affordability*. Pennie. https://pennie.com/affordability/

Pennsylvania Health Insurance Exchange Authority. (2026b, February 9). *One in five Pennie enrollees drop health coverage due to expired federal tax credits* [Press release]. https://agency.pennie.com/one-in-five-pennie-enrollees-drop-health-coverage-due-to-expired-federal-tax-credits

Pennsylvania Health Insurance Exchange Authority. (2026c). *New for 2026*. Pennie. https://pennie.com/whatsnew

Pennsylvania Health Insurance Exchange Authority. (2026d, February 1). *Terminations by county during Open Enrollment 2026* [Data file]. Pennie. https://pennie.com/wp-content/uploads/2026/02/Open-Enrollment-Comparison-2021-2026-43-Terminations-by-County-OE-2026-2.pdf

Pennsylvania Health Insurance Exchange Authority. (2026e, April 26). *Pennsylvania agencies release insurance affordability survey results*. Pennsylvania Office of Rural Health. https://www.porh.psu.edu/pennsylvania-agencies-release-insurance-affordability-survey-results/

Pennsylvania Health Access Network. (2026, April 29). *2026 survey shows Pennie plans are now unaffordable for most*. https://www.pahealthaccess.org/resource/2026-survey-shows-pennie-plans-are-now-unaffordable-for-most

Pennsylvania Insurance Department. (2026). *Pennsylvania Insurance Department releases Affordable Care Act 2026 health insurance rates*. Commonwealth of Pennsylvania. https://www.pa.gov/agencies/insurance/newsroom/aca-2026-health-insurance-rates

Pennsylvania Insurance Department. (2026f). *No Surprises Act*. Commonwealth of Pennsylvania. https://www.pa.gov/agencies/insurance/laws-regulations-notices/no-surprises-act

Pennsylvania Insurance Department. (2026g). *Request a review of an unexpected medical bill — No Surprises Act*. Commonwealth of Pennsylvania. https://www.pa.gov/services/insurance/request-a-review-of-an-unexpected-medical-bill-no-surprises-act

Pottsville Republican Herald. (2026, January 15). *Expired healthcare subsidies prove 'devastating' for some in Schuylkill County*. https://www.republicanherald.com/2026/01/15/expired-healthcare-subsidies-prove-devastating-for-some-in-schuylkill-county
